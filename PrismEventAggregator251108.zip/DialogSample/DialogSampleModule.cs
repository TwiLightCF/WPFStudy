﻿using DialogSample.ViewModels;
using DialogSample.Views;
using Prism.Ioc;
using Prism.Modularity;
using Prism.Regions;

namespace DialogSample
{
    public class DialogSampleModule : IModule
    {
        public void OnInitialized(IContainerProvider containerProvider)
        {

        }

        public void RegisterTypes(IContainerRegistry containerRegistry)
        {
            containerRegistry.RegisterForNavigation<DialogView,DialogViewModel>();
        }
    }
}