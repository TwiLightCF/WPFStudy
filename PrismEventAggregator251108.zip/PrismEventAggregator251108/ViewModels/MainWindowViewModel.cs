﻿using Microsoft.Extensions.Logging;
using Prism.Commands;
using Prism.Events;
using Prism.Mvvm;
using Prism.Regions;
using Prism.Services.Dialogs;
using PrismEventAggregator251108.Events;
using PrismEventAggregator251108.Views;
using System;
using System.Windows;
using System.Windows.Interop;

namespace PrismEventAggregator251108.ViewModels
{
    public class MainWindowViewModel : BindableBase
    {
        private readonly Logger<MainWindow> logger;
        private readonly IRegionManager _regionManager;
        private readonly IEventAggregator _eventAggregator;
        private IRegionNavigationJournal _navigationJournal;
        private readonly IDialogService _dialogService;
        private string _title = "Prism Application";
        public string Title
        {
            get { return _title; }
            set { SetProperty(ref _title, value); }
        }

        /// <summary>
        /// 在构造函数中注入参数
        /// </summary>
        /// <param name="eventAggregator"></param>
        public MainWindowViewModel(Logger<MainWindow> logger,IRegionManager regionManager,IEventAggregator eventAggregator,IDialogService dialogService)
        {
            this.logger = logger;
            _regionManager = regionManager;
            _eventAggregator = eventAggregator;
            _dialogService = dialogService;
            PubSubEventCommand = new DelegateCommand(PubSubEventMessage);
            OpenCommand = new DelegateCommand<string>(OpenMethod);
            OpenDialogCommand = new DelegateCommand<string>(OpenDialogMethod);
            BackCommand = new DelegateCommand(Back);
            NextCommand = new DelegateCommand(Next);
            // 在 UI 线程订阅，使用弱引用（keepSubscriberReferenceAlive: false）
            _eventAggregator.GetEvent<MessageEvent>()
               .Subscribe(OnMessageReceived, ThreadOption.UIThread, false, msg => msg?.Code == 500);
        }

        private void OpenDialogMethod(string obj)
        {
            DialogParameters pairs = new DialogParameters
            {
                { "Title", "我是标题" }
            };
            logger.LogInformation("我是对话框");
            _dialogService.ShowDialog("DialogView", pairs, callback =>
            {
                if (callback.Result == ButtonResult.OK)
                {
                    MessageBox.Show($"参数1：{callback.Parameters.GetValue<string>("Parameters1")}\r\n" +
                        $"参数2：{callback.Parameters.GetValue<string>("Parameters2")}");
                }
            });
        }

        private void Next()
        {
            logger.LogInformation("我是下一页");
            if (_navigationJournal.CanGoForward)
            {
                _navigationJournal.GoForward();
            }
        }

        private void Back()
        {
            logger.LogInformation("我是上一页");
            if (_navigationJournal.CanGoBack)
            {
                _navigationJournal.GoBack();
            }
        }

        private void OpenMethod(string obj)
        {
            NavigationParameters pairs = new NavigationParameters();
            pairs.Add("Keys1", "hello prism!");
            pairs.Add("Bryce", "倾盖如故，十里春风送君安");
            _regionManager.Regions["ModuleContent"].RequestNavigate(obj, navigationCallback =>
            {
                if ((bool)navigationCallback.Result)
                {
                    _navigationJournal = navigationCallback.Context.NavigationService.Journal;
                }
            }, pairs);
        }

        public void OnMessageReceived(MessageModel message)
        {
            // 在 VM 中处理：可以调用对话服务
            System.Windows.MessageBox.Show($"Code:{message.Code}\r\nMessage:{message.Message}\r\nData:{message.Data}", "系统提示");

        }

        /// <summary>
        /// 发布事件方法
        /// </summary>
        private void PubSubEventMessage()
        {
            MessageModel messageModel = new MessageModel()
            {
                Code = 500,
                Message = "操作成功",
                Data = "{数据发布成功}"
            };
            _eventAggregator.GetEvent<MessageEvent>().Publish(messageModel);
        }

        /// <summary>
        /// 创建一个命令，当执行该命令时执行发布事件的逻辑
        /// </summary>
        public DelegateCommand PubSubEventCommand { get; private set; }
        public DelegateCommand<string> OpenCommand { get; private set; }
        public DelegateCommand<string> OpenDialogCommand { get; private set; }
        public DelegateCommand BackCommand { get; private set; }
        public DelegateCommand NextCommand { get; private set; }

    }
}
