﻿using DryIoc;
using Prism.Events;
using PrismEventAggregator251108.Events;
using System.Windows;

namespace PrismEventAggregator251108.Views
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
