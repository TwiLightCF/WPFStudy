﻿using Prism.Commands;
using Prism.Mvvm;
using Prism.Regions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ModuleC.ViewModels
{
    public class ViewCViewModel : BindableBase, INavigationAware, IConfirmNavigationRequest
    {
        private string _message;
        public string Message
        {
            get { return _message; }
            set { SetProperty(ref _message, value); }
        }

        public ViewCViewModel()
        {
            Message = "View A from your Prism Module";
        }

        private string _content;
        public string Content
        {
            get { return _content; }
            set { SetProperty(ref _content, value); }
        }

        public void OnNavigatedTo(NavigationContext navigationContext)
        {
            if (navigationContext.Parameters.ContainsKey("Bryce"))
            {
                Content = navigationContext.Parameters.GetValue<string>("Bryce");
            }
        }

        public bool IsNavigationTarget(NavigationContext navigationContext)
        {
            return true;
        }

        public void OnNavigatedFrom(NavigationContext navigationContext)
        {
            
        }

        public void ConfirmNavigationRequest(NavigationContext navigationContext, Action<bool> continuationCallback)
        {
            bool result = true;

            if (MessageBox.Show("确认是否要离开当前模块？", "系统提示", MessageBoxButton.YesNo) == MessageBoxResult.No)
            {
                result = false;
            }

            continuationCallback(result);
        }
    }
}
